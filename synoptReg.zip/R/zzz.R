.onAttach <- function(libname, pkgname) {
  packageStartupMessage(paste0(c("\n****\nWelcome to synoptReg! \n",
                                 "Using synoptReg for research publication?  Please cite it!\n",
                                 "I'm an early career researcher and every citation matters.\n****\n")))}
